Pure Partner Enterprise - Clean Final - Mobile Friendly Contact

Tab Title: Pure Partner Enterprise + logo icon 💎
Header: Pure partner Enterprise (logo by side)
Slogan: just imagine it, we build it
Address: Jackies plaza, no. 3 Atiku Abubakar road, Makurdi Benue state Nigeria
Hours: 8 AM - 5 PM Monday to Friday (merged with contact details)
Email: info@purepartner.com.ng - ALL emails
Phone: 07031565116
Coords: 7.740275734616031,8.51932915904159

Contact Page Fixed:
- Removed Keep-alive debug box (Active in-memory preview etc)
- Removed broken gray map iframe box + Open in Map button + coordinate pill
- ONLY Get Directions button live: https://www.google.com/maps/dir/?api=1&destination=7.740275734616031,8.51932915904159
- Single organized card Makurdi HQ with address + opening hours merged + email + phone + Call/Email/WhatsApp grid
- Mobile friendly, rounded-2xl, touch targets

Features:
- Keep-alive baked background app/api/keep-alive every 72h (no UI debug)
- PureBot chatbot scoped to webapp only
- Download App iOS/Android/Mac/Windows offline PWA
- Enterprise Solution ₦2M+
- Supabase Live Connect panel in admin purepartner.ng/admin (not contact)
- LIVE NEWS ticker finance tech software AI ICT jobs
- Offline + analytics

Deploy to purepartner.com.ng / Vercel
