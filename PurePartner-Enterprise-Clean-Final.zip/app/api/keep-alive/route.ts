import { createClient } from '@supabase/supabase-js'
export const dynamic = 'force-dynamic'
export async function GET() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL!
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  const supabase = createClient(url, key)
  await supabase.from('site_settings').select('id').limit(1)
  return Response.json({ ok: true, pinged: new Date().toISOString(), location: 'Jackies plaza, no. 3 Atiku Abubakar road, Makurdi Benue state Nigeria', tab: 'Pure Partner Enterprise', email: 'info@purepartner.com.ng' })
}
